<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Homepage - Car rental homepage</title>
    <meta name="description" content="" />
    <link rel="alternate" href="" hreflang="en" />

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website" />
    <meta property="og:url" content="" />
    <meta property="og:title" content="" />
    <meta property="og:description" content="" />
    <meta property="og:image" content="" />
    <!-- ./Open Graph / Facebook -->

    <!-- CSS Files Section -->
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.3.0/animate.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.13.2/themes/base/jquery-ui.css">

    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
</head>

<body>
    <!-- Navbar Section -->
    <?php include_once 'inc/nav.php' ?>
    <!-- Navbar Section END -->

    <!-- Header Section -->
    <div class="header-section">
        <div class="header-block">
            <div class="left-col">
                <h1 class="title">Welcome to our website</h1>

                <div class="text-block">
                    <p class="text">
                        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Eligendi temporibus quo explicabo, eum rerum error excepturi nihil architecto enim facere adipisci ad nam maxime, autem, inventore amet optio! Voluptatum, inventore.
                    </p>
                </div>
                <div class="btn-block">
                    <a href="#" class="btn">Contact us</a>
                </div>
            </div>
            <div class="header-bg">
                <img src="assets/images/hero_01.jpg" alt="hero_bg">
            </div>
        </div>
    </div>
    <!-- Header Section END -->

    <!-- Booking Section -->
    <div class="booking-section">
        <form method="post" class="booking-form">
            <div class="input-block">
                <label for="from">From</label>
                <input type="text" name="from" id="from" placeholder="Destination start" class="input">
            </div>
            <div class="input-block">
                <label for="from">To</label>
                <input type="text" name="from" id="to" placeholder="Destination end" class="input">
            </div>
            <div class="input-block">
                <label for="passenger">Passengers</label>
                <input type="text" name="from" id="passenger" placeholder="Number of passengers" class="input">
            </div>
            <div class="input-block">
                <label for="date">Date of departure</label>
                <input type="text" name="from" id="date" placeholder="Select a date" class="input">
            </div>
            <div class="input-block">
                <label for="date-2">Return date</label>
                <input type="text" name="from" id="date-2" placeholder="Select a date" class="input">
            </div>
            <div class="input-block">
                <label for="Vehicle">Choose a vehicle</label>
                <select name="" id="" class="input select">
                    <option value="Volvo">Volvo</option>
                    <option value="Volkswagen">Volkswagen</option>
                    <option value="Toyota">Toyota</option>
                    <option value="Ford">Ford</option>
                    <option value="BMW">BMW</option>
                </select>
            </div>
            <div class="btn-block">
                <a href="#" class="btn">Book Now</a>
            </div>
        </form>
    </div>
    <!-- Booking Section END -->

    <!-- Services Section -->
    <div class="service-section-2">
        <div class="service-grid">
            <div class="left-col">
                <div class="service-photo">
                    <img src="assets/images/01.jpg" alt="service-bg">
                </div>
            </div>
            <div class="right-col">
                <div class="service-desc">
                    <div class="title-block">
                        <h2 class="title">Who your compnay name?</h2>
                    </div>
                    <div class="text-block grid-2">
                        <div class="text">
                            <i class="fa-solid fa-phone-volume"></i> <a href="tel:00000000000">00000000000000</a>
                        </div>
                        <div class="text">
                            <i class="fa-solid fa-phone-volume"></i> <a href="tel:00000000000">00000000000000</a>
                        </div>
                    </div>
                    <div class="text-block">
                        <p class="text">
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio veniam eveniet facilis impedit assumenda unde culpa excepturi vero dolores aperiam blanditiis corporis error atque, odit commodi. Id obcaecati optio molestias! Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet rem quidem voluptatibus, cupiditate nihil quos porro laudantium iure commodi. Qui doloribus adipisci nulla harum quasi eligendi mollitia ipsa vero ducimus?
                        </p>
                    </div>
                    <div class="btn-block">
                        <a href="#" class="btn">Contact us</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Services Section END -->

    <!-- Title Block -->
    <div class="custom-title-block">
        <h2 class="title">Top rental cars</h2>
    </div>
    <!-- Title Block -->

    <!-- Course Section -->
    <div class="course-section">
        <div class="course-wrap">
            <div class="left-col">
                <div class="course-photo wow fadeInup">
                    <img src="assets/images/01.jpg" alt="course-photo">
                </div>
            </div>
            <div class="right-col">
                <div class="course-title">
                    <h2 class="title wow fadeInLeft">Volvo Car</h2>
                </div>
                <div class="course-facilities">
                    <div class="facilities wow fadeInUp">
                        <i class="fa-sharp fa-regular fa-calendar-days"></i>
                        <p><b>Door:</b> 2 door</p>
                    </div>
                    <div class="facilities wow fadeInUp">
                        <i class="fa-regular fa-clock"></i>
                        <p><b>Laugage:</b> 20kg</p>
                    </div>
                    <div class="facilities wow fadeInUp">
                        <i class="fa-solid fa-location-dot"></i>
                        <p><b>Airconditionar:</b> Yes</p>
                    </div>
                    <div class="facilities wow fadeInUp">
                        <i class="fa-sharp fa-regular fa-user"></i>
                        <p><b>Available Seat:</b> 4 Seat</p>
                    </div>
                </div>

                <div class="btn-block">
                    <a href="#" target="_blank" class="btn wow fadeInUp">book now</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Course Section END -->

    <!-- Course Section -->
    <div class="course-section reverse">
        <div class="course-wrap">
            <div class="left-col">
                <div class="course-photo wow fadeInup">
                    <img src="assets/images/02.jpg" alt="course-photo">
                </div>
            </div>
            <div class="right-col">
                <div class="course-title">
                    <h2 class="title wow fadeInLeft">BMW Car</h2>
                </div>
                <div class="course-facilities">
                    <div class="facilities wow fadeInUp">
                        <i class="fa-sharp fa-regular fa-calendar-days"></i>
                        <p><b>Door:</b> 2 door</p>
                    </div>
                    <div class="facilities wow fadeInUp">
                        <i class="fa-regular fa-clock"></i>
                        <p><b>Laugage:</b> 20kg</p>
                    </div>
                    <div class="facilities wow fadeInUp">
                        <i class="fa-solid fa-location-dot"></i>
                        <p><b>Airconditionar:</b> Yes</p>
                    </div>
                    <div class="facilities wow fadeInUp">
                        <i class="fa-sharp fa-regular fa-user"></i>
                        <p><b>Available Seat:</b> 4 Seat</p>
                    </div>
                </div>

                <div class="btn-block">
                    <a href="#" target="_blank" class="btn wow fadeInUp">book now</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Course Section END -->

    <!-- Custom Button Block -->
    <div class="custom-btn-block">
        <a href="#" class="btn">Check more</a>
    </div>
    <!-- Custom BUtton Block END -->

    <!-- Banner Section -->
    <div class="banner-section pt-0">
        <div class="title-block">
            <h2 class="title">Our Services & Why choose us?</h2>
            <div class="subtitle">We provide these services upon request offer</div>
        </div>

        <div class="text-block grid-center">
            <ul class="list-text list-4">
                <li>Cultural excursion</li>
                <li>Cultural excursion</li>
                <li>University trip</li>
                <li>Wedding trip</li>
                <li>University trip</li>
                <li>Tourist spot trip</li>
                <li>Tourist spot trip</li>
                <li>Wedding trip</li>
            </ul>
        </div>
    </div>
    <!-- Banner Section END -->

    <!-- Banner Section -->
    <div class="banner-section pt-0 grid-4">
        <div class="text-block">
            <div class="icon">
                <i class="fa-sharp fa-solid fa-tags"></i>
            </div>
            <p class="text big-text">Low cost</p>
            <p class="text">We charge only fair and best possible guaranteed price</p>
        </div>
        <div class="text-block">
            <div class="icon">
                <i class="fa-sharp fa-solid fa-tags"></i>
            </div>
            <p class="text big-text">Experience</p>
            <p class="text">Since 15+ years we have operate our business sucessfully</p>
        </div>
        <div class="text-block">
            <div class="icon">
                <i class="fa-sharp fa-solid fa-tags"></i>
            </div>
            <p class="text big-text">Extra charge free</p>
            <p class="text">We always care our customer. As per their short need we added few futures.</p>
        </div>
        <div class="text-block">
            <div class="icon">
                <i class="fa-sharp fa-solid fa-tags"></i>
            </div>
            <p class="text big-text">Prayer time</p>
            <p class="text">We added prayer time break while we're traving customer destination.</p>
        </div>
        <div class="btn-block grid-1">
            <a href="#" class="btn">Contact us</a>
        </div>
    </div>
    <!-- Banner Section END -->

    <!-- Title Block -->
    <div class="custom-title-block pt-0">
        <h2 class="title">Our partners</h2>
    </div>
    <!-- Title Block -->

    <!-- Banner Section -->
    <div class="banner-section grid-3">
        <div class="text-block">
            <div class="icon">
                <i class="fa-sharp fa-solid fa-tags"></i>
            </div>
            <p class="text bold">San francisco govt College</p>
        </div>
        <div class="text-block">
            <div class="icon">
                <i class="fa-sharp fa-solid fa-tags"></i>
            </div>
            <p class="text bold">Lose blank Botique hotel</p>
        </div>
        <div class="text-block">
            <div class="icon">
                <i class="fa-sharp fa-solid fa-tags"></i>
            </div>
            <p class="text bold">San francisco govt College</p>
        </div>
        <div class="text-block">
            <div class="icon">
                <i class="fa-sharp fa-solid fa-tags"></i>
            </div>
            <p class="text bold">Lose blank Botique hotel</p>
        </div>
        <div class="text-block">
            <div class="icon">
                <i class="fa-sharp fa-solid fa-tags"></i>
            </div>
            <p class="text bold">San francisco govt College</p>
        </div>
        <div class="text-block">
            <div class="icon">
                <i class="fa-sharp fa-solid fa-tags"></i>
            </div>
            <p class="text bold">Lose blank Botique hotel</p>
        </div>
        <div class="btn-block grid-1">
            <a href="#" class="btn">Contact us</a>
        </div>
    </div>
    <!-- Banner Section END -->

    <!-- FAQ Section -->
    <div class="faq-section">
        <div class="title-block">
            <div class="title">FAQS</div>
        </div>
        <div id="accordion">
            <h3>How long it will take to qualify as a eyes and lip permanent makeup artists?</h3>
            <div>
                <p>
                    It takes around 3-6 month to become qualified and confident in delivering permanent eyes and lips tattoo treatments, however this depend on each student.
                </p>
            </div>
            <h3>Where is the course?</h3>
            <div>
                <p>
                    You can start your eyes and lip permanent makeup journey from home with at-home blended learning. Our academy days are available in <a href="">South Elmsall</a> in West Yorkshire, <a href="">Milton Keynes</a> in Buckinghamshire and Purley in London.
                </p>
            </div>
            <h3>What package courses are available?</h3>
            <div>
                <p>
                    K.B Pro offer several permanent makeup package courses, you can train in <a href="">Permanent Full Face Makeup</a> giving to skills to create permanent brows, eyes and lips.
                </p>
            </div>
        </div>
    </div>
    <!-- FAQ Section END -->

    <!-- Register Section -->
    <div class="register-section">
        <div class="title-block">
            <h2 class="title wow slideInUp">Contact us</h2>
        </div>
        <div id="msg"></div>
        <form method="post" action="" id="mail" class="register-form">
            <div class="field-block wow slideInUp">
                <div class="text-block">
                    <p class="text">
                        First Name
                    </p>
                </div>

                <div class="input-block">
                    <input type="text" name="name" id="name" class="input">
                </div>
            </div>
            <div class="field-block wow slideInUp">
                <div class="text-block">
                    <p class="text">
                        Last Name
                    </p>
                </div>

                <div class="input-block">
                    <input type="text" name="l_name" id="l_name" class="input">
                </div>
            </div>
            <div class="field-block wow slideInUp">
                <div class="text-block">
                    <p class="text">
                        Email
                    </p>
                </div>

                <div class="input-block">
                    <input type="text" name="email" id="email" class="input">
                </div>
            </div>
            <div class="field-block wow slideInUp">
                <div class="text-block">
                    <p class="text">
                        WhatsApp Number
                    </p>
                </div>

                <div class="input-block">
                    <input type="number" name="whatsapp" id="whatsapp" class="input">
                </div>
            </div>
            <div class="field-block grid-1 wow slideInUp">
                <div class="text-block">
                    <p class="text">
                        Message
                    </p>
                </div>

                <div class="input-block">
                    <textarea name="des" id="des" class="input" cols="10" rows="5"></textarea>
                </div>
            </div>
            <div class="field-block grid-1 wow slideInUp">
                <div class="g-recaptcha" data-sitekey="43gfdg"></div>
            </div>
            <div class="field-block grid-1 wow slideInUp">
                <input type="submit" class="btn" value="Send Message" name="" id="">
            </div>
        </form>
    </div>
    <!-- Register Section END -->

    <!-- Footer Section -->
    <?php include_once 'inc/footer.php'; ?>
    <!-- Footer Section END -->

    <!-- Back to TOP -->
    <div id="progress">
        <span id="progress-value">&#x1F815;</span>
    </div>
    <!-- Back to TOP END -->

    <!-- LOADER -->
    <div class="loader">
        <div></div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/3.11.4/gsap.min.js"></script>
    <script src="https://code.jquery.com/ui/1.13.2/jquery-ui.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.js"></script>
    <script src="https://kit.fontawesome.com/5356aed19a.js" crossorigin="anonymous"></script>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script src="assets/js/main.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <!-----------
    LOADER SCRIPT
    ------------>
    <script>
        $(window).on('load', function() {
            $(".loader").fadeOut(1000);
        });
    </script>

    <script>
        $(document).ready(function() {
            //wow js init
            new WOW().init();

            var nameErr = true;
            var whatsappErr = true;
            var emailErr = true;
            var desErr = true;
            var name, whatsapp, email, des;

            //FORM VALIDATION
            $("#name").on("keyup", function() {
                name = $(this).val();

                if (name.length > 35 || name.length < 5) {
                    $('#msg').html("minimum 5 & maximum 35 character require").fadeIn();
                    nameErr = true;
                } else {
                    $('#msg').text("");
                    nameErr = false;
                }
            });

            $("#whatsapp").on("keyup", function() {
                whatsapp = $(this).val();

                if (whatsapp.length > 14 || whatsapp.length < 5) {
                    $('#msg').html("minimum 5 & maximum 14 number require").fadeIn();
                    whatsappErr = true;
                } else {
                    $('#msg').text("");
                    whatsappErr = false;
                }
            });

            $("#email").on("keyup", function() {
                email = $(this).val();
                var regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

                if (regex.test(email)) {
                    $('#msg').text("");
                    emailErr = false;

                } else {
                    $('#msg').text("email must be valid");
                    emailErr = true;
                }
            });

            $("#des").on("keyup", function() {
                des = $(this).val();

                if (des.length > 20 || des.length < 2) {
                    $('#msg').html("minimum 2 & maximum 20 number require").fadeIn();
                    desErr = true;
                } else {
                    $('#msg').text("");
                    desErr = false;
                }
            });

            $("#mail").on("submit", function() {
                event.preventDefault();

                if (nameErr == false && whatsappErr == false && emailErr == false && desErr == false) {
                    var response = grecaptcha.getResponse();

                    if (response.length == 0) {
                        $("#msg").text("Please verify you are not robot");
                    } else {
                        $.ajax({
                            url: "mail.php",
                            method: "POST",
                            data: $("#mail").serialize(),
                            success: function(result) {
                                $("#email_form").html(result);
                            }
                        });

                        $("#msg").text();
                    }
                } else {
                    alert("Please fill up all field correctly");
                }
            });
        });

        $(function() {
            $("#accordion").accordion();
        });

        //datepicker
        $(function() {
            $("#date").datepicker();
        });
        $(function() {
            $("#date-2").datepicker();
        });
        $(document).ready(function() {
            $('.select').select2();
        });
    </script>
</body>

</html>